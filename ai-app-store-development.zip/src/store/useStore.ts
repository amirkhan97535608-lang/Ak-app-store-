
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { AppData, Notification, APPS, NOTIFICATIONS } from '@/data/mockData';

export type ThemeColor = 'blue' | 'black' | 'green' | 'purple' | 'sky';
// 'white' isn't a great primary color for buttons, mapping 'white' from prompt to 'blue' default or 'slate'
// Prompt: White, Black, Green, Purple, Sky Blue.
// Let's map: White -> Slate (Neutral), Black -> Zinc (Neutral Dark), Green -> Emerald, Purple -> Violet, Sky Blue -> Sky.

export type AppTheme = 'slate' | 'zinc' | 'emerald' | 'violet' | 'sky';

interface DownloadItem {
  appId: string;
  progress: number;
  status: 'pending' | 'downloading' | 'completed';
}

interface UserProfile {
  name: string;
  email: string;
  avatar: string;
  id: string;
}

interface AppState {
  showSplash: boolean;
  setShowSplash: (show: boolean) => void;

  darkMode: boolean;
  toggleDarkMode: () => void;
  
  themeColor: AppTheme;
  setThemeColor: (color: AppTheme) => void;

  user: UserProfile;
  updateUser: (user: Partial<UserProfile>) => void;

  downloads: DownloadItem[];
  startDownload: (appId: string) => void;
  updateDownloadProgress: (appId: string, progress: number) => void;
  completeDownload: (appId: string) => void;
  clearCompletedDownloads: () => void;

  notifications: Notification[];
  markNotificationRead: (id: string) => void;
  
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      showSplash: true,
      setShowSplash: (show) => set({ showSplash: show }),

      darkMode: false,
      toggleDarkMode: () => set((state) => ({ darkMode: !state.darkMode })),

      themeColor: 'sky',
      setThemeColor: (color) => set({ themeColor: color }),

      user: {
        name: 'Alex Doe',
        email: 'alex.doe@example.com',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&h=200&fit=crop',
        id: 'AK-88239'
      },
      updateUser: (updates) => set((state) => ({ user: { ...state.user, ...updates } })),

      downloads: [],
      startDownload: (appId) => {
        const existing = get().downloads.find(d => d.appId === appId);
        if (existing && existing.status === 'completed') return;
        
        set((state) => ({
          downloads: [...state.downloads.filter(d => d.appId !== appId), { appId, progress: 0, status: 'downloading' }]
        }));

        // Simulate download
        let progress = 0;
        const interval = setInterval(() => {
          progress += 10;
          if (progress >= 100) {
            clearInterval(interval);
            get().completeDownload(appId);
          } else {
            get().updateDownloadProgress(appId, progress);
          }
        }, 500);
      },
      updateDownloadProgress: (appId, progress) => set((state) => ({
        downloads: state.downloads.map(d => d.appId === appId ? { ...d, progress } : d)
      })),
      completeDownload: (appId) => set((state) => ({
        downloads: state.downloads.map(d => d.appId === appId ? { ...d, progress: 100, status: 'completed' } : d)
      })),
      clearCompletedDownloads: () => set((state) => ({
        downloads: state.downloads.filter(d => d.status !== 'completed')
      })),

      notifications: NOTIFICATIONS,
      markNotificationRead: (id) => set((state) => ({
        notifications: state.notifications.map(n => n.id === id ? { ...n, read: true } : n)
      })),

      searchQuery: '',
      setSearchQuery: (query) => set({ searchQuery: query }),
    }),
    {
      name: 'ak-app-store-storage',
      partialize: (state) => ({ 
        darkMode: state.darkMode, 
        themeColor: state.themeColor,
        user: state.user,
        downloads: state.downloads, // Persist downloads for realism
        notifications: state.notifications
      }),
    }
  )
);
