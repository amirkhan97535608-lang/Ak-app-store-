
import { AppTheme } from "@/store/useStore";

export const THEME_CONFIG: Record<AppTheme, {
    name: string;
    primaryBg: string; // For buttons, badges
    primaryText: string; // For active text
    gradient: string; // For headers, cards
    ring: string; // For focus rings
    border: string; // For active borders
}> = {
  slate: {
    name: 'Default',
    primaryBg: 'bg-slate-800',
    primaryText: 'text-slate-800',
    gradient: 'bg-gradient-to-r from-slate-700 to-slate-900',
    ring: 'ring-slate-800',
    border: 'border-slate-800'
  },
  zinc: {
    name: 'Dark',
    primaryBg: 'bg-zinc-900',
    primaryText: 'text-zinc-900',
    gradient: 'bg-gradient-to-r from-zinc-800 to-black',
    ring: 'ring-zinc-900',
    border: 'border-zinc-900'
  },
  emerald: {
    name: 'Green',
    primaryBg: 'bg-emerald-500',
    primaryText: 'text-emerald-600',
    gradient: 'bg-gradient-to-r from-emerald-500 to-teal-600',
    ring: 'ring-emerald-500',
    border: 'border-emerald-500'
  },
  violet: {
    name: 'Purple',
    primaryBg: 'bg-violet-500',
    primaryText: 'text-violet-600',
    gradient: 'bg-gradient-to-r from-violet-500 to-fuchsia-600',
    ring: 'ring-violet-500',
    border: 'border-violet-500'
  },
  sky: {
    name: 'Sky',
    primaryBg: 'bg-sky-500',
    primaryText: 'text-sky-600',
    gradient: 'bg-gradient-to-r from-sky-500 to-blue-600',
    ring: 'ring-sky-500',
    border: 'border-sky-500'
  }
};

export const getThemeConfig = (theme: AppTheme) => {
  return THEME_CONFIG[theme] || THEME_CONFIG['sky'];
};

