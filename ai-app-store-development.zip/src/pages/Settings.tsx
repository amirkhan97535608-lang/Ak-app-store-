
import React from 'react';
import { User, Moon, Sun, Type, Globe, ChevronRight } from 'lucide-react';
import { useStore, AppTheme } from '@/store/useStore';
import { cn } from '@/utils/cn';
import { THEME_CONFIG, getThemeConfig } from '@/utils/theme';

export const Settings = () => {
  const { darkMode, toggleDarkMode, themeColor, setThemeColor, user } = useStore();
  const theme = getThemeConfig(themeColor);

  const SettingItem = ({ icon: Icon, label, value, onClick }: any) => (
    <button 
        onClick={onClick}
        className={cn(
            "flex items-center justify-between w-full p-4 rounded-xl transition-colors",
            darkMode ? "bg-zinc-800 hover:bg-zinc-700" : "bg-white hover:bg-slate-50 shadow-sm border border-slate-100"
        )}
    >
        <div className="flex items-center gap-3">
            <div className={cn("p-2 rounded-lg", darkMode ? "bg-zinc-700 text-zinc-300" : "bg-slate-100 text-slate-600")}>
                <Icon size={20} />
            </div>
            <span className={cn("font-medium", darkMode ? "text-white" : "text-slate-900")}>{label}</span>
        </div>
        <div className="flex items-center gap-2">
            {value && <span className="text-sm text-zinc-500">{value}</span>}
            <ChevronRight size={16} className="text-zinc-400" />
        </div>
    </button>
  );

  return (
    <div className={cn("min-h-screen pt-[70px] pb-[80px] px-4 space-y-6", darkMode ? "bg-zinc-900" : "bg-slate-50")}>
      
      {/* Profile Section */}
      <div className={cn(
          "flex items-center gap-4 p-4 rounded-2xl text-white shadow-lg transition-colors",
          theme.gradient
      )}>
          <img src={user.avatar} alt="Profile" className="w-16 h-16 rounded-full border-2 border-white/50" />
          <div className="flex-1">
              <h2 className="text-lg font-bold">{user.name}</h2>
              <p className="text-sm opacity-90">{user.email}</p>
              <p className="text-xs opacity-75 mt-1">ID: {user.id}</p>
          </div>
          <button className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors">
              <User size={20} />
          </button>
      </div>

      {/* Appearance */}
      <div className="space-y-3">
          <h3 className={cn("font-bold ml-1", darkMode ? "text-zinc-400" : "text-slate-500")}>Appearance</h3>
          
          {/* Dark Mode */}
          <button 
                onClick={toggleDarkMode}
                className={cn(
                    "flex items-center justify-between w-full p-4 rounded-xl transition-colors",
                    darkMode ? "bg-zinc-800 hover:bg-zinc-700" : "bg-white hover:bg-slate-50 shadow-sm border border-slate-100"
                )}
            >
                <div className="flex items-center gap-3">
                    <div className={cn("p-2 rounded-lg", darkMode ? "bg-zinc-700 text-zinc-300" : "bg-slate-100 text-slate-600")}>
                        {darkMode ? <Moon size={20} /> : <Sun size={20} />}
                    </div>
                    <span className={cn("font-medium", darkMode ? "text-white" : "text-slate-900")}>Dark Mode</span>
                </div>
                <div className={cn(
                    "w-12 h-6 rounded-full relative transition-colors",
                    darkMode ? theme.primaryBg : "bg-zinc-300"
                )}>
                    <div className={cn(
                        "absolute top-1 w-4 h-4 rounded-full bg-white transition-all",
                        darkMode ? "left-7" : "left-1"
                    )} />
                </div>
          </button>

          {/* Theme Color */}
          <div className={cn(
              "p-4 rounded-xl space-y-3",
              darkMode ? "bg-zinc-800" : "bg-white shadow-sm border border-slate-100"
          )}>
              <span className={cn("font-medium", darkMode ? "text-white" : "text-slate-900")}>Theme Color</span>
              <div className="flex gap-3 overflow-x-auto pb-2">
                  {(Object.entries(THEME_CONFIG) as [AppTheme, typeof THEME_CONFIG[AppTheme]][]).map(([key, config]) => (
                      <button 
                        key={key}
                        onClick={() => setThemeColor(key)}
                        className={cn(
                            "w-10 h-10 rounded-full flex items-center justify-center transition-all shrink-0",
                            config.primaryBg,
                            themeColor === key ? cn("ring-2 ring-offset-2 scale-110", config.ring) : "opacity-70 hover:opacity-100"
                        )}
                        title={config.name}
                      />
                  ))}
              </div>
          </div>
      </div>

      {/* General */}
      <div className="space-y-3">
          <h3 className={cn("font-bold ml-1", darkMode ? "text-zinc-400" : "text-slate-500")}>General</h3>
          <SettingItem icon={Type} label="Font Size" value="Medium" />
          <SettingItem icon={Globe} label="Language" value="English" />
      </div>

    </div>
  );
};
