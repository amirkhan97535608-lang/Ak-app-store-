
import React from 'react';
import { Share, Download, Star, CheckCircle } from 'lucide-react';
import { useParams } from 'react-router-dom';
import { APPS } from '@/data/mockData';
import { useStore } from '@/store/useStore';
import { cn } from '@/utils/cn';
import { getThemeConfig } from '@/utils/theme';

export const AppDetails = () => {
  const { id } = useParams();
  const { darkMode, themeColor, downloads, startDownload } = useStore();
  const app = APPS.find(a => a.id === id);

  if (!app) return <div className="pt-20 text-center">App not found</div>;

  const downloadStatus = downloads.find(d => d.appId === app.id);
  const isDownloading = downloadStatus?.status === 'downloading';
  const isCompleted = downloadStatus?.status === 'completed';
  const progress = downloadStatus?.progress || 0;

  const btnColorClass = getThemeConfig(themeColor).primaryBg + ' text-white';

  return (
    <div className={cn("min-h-screen pt-[70px] pb-[80px] px-4 space-y-6", darkMode ? "bg-zinc-900 text-white" : "bg-slate-50 text-slate-900")}>
      
      {/* Header Info */}
      <div className="flex gap-4">
        <img src={app.icon} alt={app.name} className="w-24 h-24 rounded-2xl object-cover shadow-lg" />
        <div className="flex flex-col justify-center gap-1">
            <h1 className="text-xl font-bold">{app.name}</h1>
            <p className={cn("text-sm", darkMode ? "text-zinc-400" : "text-slate-500")}>{app.category}</p>
            <div className="flex items-center gap-4 mt-2">
                <div className="flex flex-col items-center">
                    <span className="font-bold text-sm">{app.rating}</span>
                    <span className="text-[10px] text-zinc-500">Rating</span>
                </div>
                <div className="w-px h-6 bg-zinc-300 dark:bg-zinc-700"></div>
                <div className="flex flex-col items-center">
                    <span className="font-bold text-sm">{app.size}</span>
                    <span className="text-[10px] text-zinc-500">Size</span>
                </div>
                <div className="w-px h-6 bg-zinc-300 dark:bg-zinc-700"></div>
                <div className="flex flex-col items-center">
                    <span className="font-bold text-sm">{app.downloads}</span>
                    <span className="text-[10px] text-zinc-500">Downloads</span>
                </div>
            </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-4">
          <button 
            disabled={isCompleted || isDownloading}
            onClick={() => startDownload(app.id)}
            className={cn(
                "flex-1 h-12 rounded-xl font-bold flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-80 disabled:cursor-not-allowed relative overflow-hidden",
                isCompleted ? "bg-zinc-200 text-zinc-600 dark:bg-zinc-700 dark:text-zinc-300" : btnColorClass
            )}
          >
            {isDownloading && (
                <div 
                    className="absolute left-0 top-0 bottom-0 bg-white/20 transition-all duration-300" 
                    style={{ width: `${progress}%` }}
                />
            )}
            
            {isCompleted ? (
                <>
                    <CheckCircle size={20} className="text-emerald-500" />
                    <span>Open</span>
                </>
            ) : isDownloading ? (
                <span>{progress}%</span>
            ) : (
                <>
                    <Download size={20} />
                    <span>Install</span>
                </>
            )}
          </button>
          
          <button className={cn(
              "w-12 h-12 rounded-xl flex items-center justify-center",
              darkMode ? "bg-zinc-800 text-white" : "bg-white text-slate-900 border border-slate-200"
          )}>
              <Share size={20} />
          </button>
      </div>

      {/* Screenshots */}
      <div className="space-y-3">
          <h3 className="font-bold text-lg">Preview</h3>
          {app.screenshots.length > 0 ? (
            <div className="flex overflow-x-auto gap-3 pb-4 scrollbar-hide -mx-4 px-4">
                {app.screenshots.map((shot, idx) => (
                    <img key={idx} src={shot} alt="Screenshot" className="h-64 rounded-xl object-cover" />
                ))}
            </div>
          ) : (
              <p className="text-zinc-500 italic">No screenshots available</p>
          )}
      </div>

      {/* Description */}
      <div className="space-y-2">
          <h3 className="font-bold text-lg">About this app</h3>
          <p className={cn("text-sm leading-relaxed", darkMode ? "text-zinc-300" : "text-slate-600")}>
              {app.description}
          </p>
      </div>

      {/* Info Grid */}
      <div className="grid grid-cols-2 gap-4 pt-4">
          <div className="p-3 rounded-xl bg-zinc-100 dark:bg-zinc-800">
              <span className="text-xs text-zinc-500 block">Version</span>
              <span className="font-medium">{app.version}</span>
          </div>
          <div className="p-3 rounded-xl bg-zinc-100 dark:bg-zinc-800">
              <span className="text-xs text-zinc-500 block">Updated</span>
              <span className="font-medium">2 days ago</span>
          </div>
      </div>

    </div>
  );
};
