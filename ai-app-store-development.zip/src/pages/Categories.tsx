
import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { CATEGORIES, APPS } from '@/data/mockData';
import { CategoryChip } from '@/components/shared/CategoryChip';
import { AppListItem } from '@/components/shared/AppListItem';
import { useStore } from '@/store/useStore';
import { cn } from '@/utils/cn';

export const Categories = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const { darkMode } = useStore();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  useEffect(() => {
    const cat = searchParams.get('cat');
    if (cat) {
        setSelectedCategory(cat);
    } else {
        setSelectedCategory(null);
    }
  }, [searchParams]);

  const handleCategoryClick = (catName: string) => {
      if (selectedCategory === catName) {
          setSearchParams({});
      } else {
          setSearchParams({ cat: catName });
      }
  };

  const filteredApps = selectedCategory 
    ? APPS.filter(app => app.category === selectedCategory) 
    : APPS;

  return (
    <div className={cn("min-h-screen pt-[70px] pb-[80px] px-4 space-y-6", darkMode ? "bg-zinc-900" : "bg-slate-50")}>
      
      {/* Category List */}
      <div className="flex flex-wrap gap-2">
        <CategoryChip 
            category={{ id: 'all', name: 'All', iconName: 'Grid', count: 0 }} 
            active={!selectedCategory}
            onClick={() => setSearchParams({})}
        />
        {CATEGORIES.map(cat => (
            <CategoryChip 
                key={cat.id} 
                category={cat} 
                active={selectedCategory === cat.name}
                onClick={() => handleCategoryClick(cat.name)}
            />
        ))}
      </div>

      {/* App List */}
      <div className="flex flex-col gap-3">
          {filteredApps.map(app => (
              <AppListItem key={app.id} app={app} />
          ))}
          {filteredApps.length === 0 && (
              <p className="text-center text-zinc-500 mt-10">No apps found in this category.</p>
          )}
      </div>

    </div>
  );
};
