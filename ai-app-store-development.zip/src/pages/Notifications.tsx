
import React from 'react';
import { Bell, Info, CheckCircle } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { cn } from '@/utils/cn';

export const Notifications = () => {
  const { darkMode, notifications, markNotificationRead } = useStore();

  return (
    <div className={cn("min-h-screen pt-[70px] pb-[80px] px-4 space-y-4", darkMode ? "bg-zinc-900" : "bg-slate-50")}>
      
      {notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center pt-20 text-zinc-500">
              <Bell size={48} className="mb-4 opacity-50" />
              <p>No notifications yet</p>
          </div>
      ) : (
          notifications.map(note => (
            <div 
                key={note.id}
                onClick={() => markNotificationRead(note.id)}
                className={cn(
                    "p-4 rounded-xl flex gap-4 transition-all border-l-4",
                    darkMode ? "bg-zinc-800" : "bg-white shadow-sm border border-slate-100",
                    note.read 
                        ? (darkMode ? "border-l-zinc-600 opacity-60" : "border-l-slate-300 opacity-60") 
                        : "border-l-sky-500"
                )}
            >
                <div className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center shrink-0",
                    darkMode ? "bg-zinc-700 text-zinc-300" : "bg-slate-100 text-slate-600"
                )}>
                    {note.type === 'update' ? <CheckCircle size={20} /> : <Info size={20} />}
                </div>
                <div className="flex-1">
                    <div className="flex justify-between items-start">
                        <h3 className={cn("font-bold text-sm", darkMode ? "text-white" : "text-slate-900")}>
                            {note.title}
                        </h3>
                        <span className="text-[10px] text-zinc-500">{note.timestamp}</span>
                    </div>
                    <p className={cn("text-xs mt-1", darkMode ? "text-zinc-400" : "text-slate-500")}>
                        {note.message}
                    </p>
                </div>
            </div>
          ))
      )}

    </div>
  );
};
