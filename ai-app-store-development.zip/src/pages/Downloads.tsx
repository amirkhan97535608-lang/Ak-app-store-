
import React, { useState } from 'react';
import { APPS } from '@/data/mockData';
import { useStore } from '@/store/useStore';
import { cn } from '@/utils/cn';
import { AppListItem } from '@/components/shared/AppListItem';
import { Trash2 } from 'lucide-react';

export const Downloads = () => {
  const { darkMode, downloads, clearCompletedDownloads, themeColor } = useStore();
  const [activeTab, setActiveTab] = useState<'progress' | 'completed'>('progress');

  const inProgressItems = downloads.filter(d => d.status === 'downloading' || d.status === 'pending');
  const completedItems = downloads.filter(d => d.status === 'completed');

  const getApp = (id: string) => APPS.find(a => a.id === id)!;

  const tabActiveClass = {
    slate: 'border-slate-900 text-slate-900',
    zinc: 'border-black text-black',
    emerald: 'border-emerald-500 text-emerald-500',
    violet: 'border-violet-500 text-violet-500',
    sky: 'border-sky-500 text-sky-500',
  }[themeColor];

  // In dark mode, text color overrides
  const getTabClass = (isActive: boolean) => {
    if (!isActive) return "text-zinc-500 border-transparent";
    if (darkMode) {
        return "text-white border-white"; // Simplified for dark mode
    }
    return tabActiveClass;
  };

  return (
    <div className={cn("min-h-screen pt-[70px] pb-[80px] px-4 space-y-6", darkMode ? "bg-zinc-900" : "bg-slate-50")}>
      
      {/* Tabs */}
      <div className="flex border-b border-zinc-200 dark:border-zinc-800">
        <button
            onClick={() => setActiveTab('progress')}
            className={cn(
                "flex-1 py-3 text-sm font-medium border-b-2 transition-all",
                getTabClass(activeTab === 'progress')
            )}
        >
            In Progress ({inProgressItems.length})
        </button>
        <button
            onClick={() => setActiveTab('completed')}
            className={cn(
                "flex-1 py-3 text-sm font-medium border-b-2 transition-all",
                getTabClass(activeTab === 'completed')
            )}
        >
            Completed ({completedItems.length})
        </button>
      </div>

      {/* Content */}
      <div className="space-y-4">
          {activeTab === 'progress' ? (
              inProgressItems.length > 0 ? (
                  inProgressItems.map(item => {
                      const app = getApp(item.appId);
                      return (
                        <div key={item.appId} className="space-y-2">
                            <AppListItem app={app} />
                            <div className="h-1 bg-zinc-200 dark:bg-zinc-800 rounded-full overflow-hidden">
                                <div 
                                    className={cn("h-full transition-all duration-300", 
                                        darkMode ? "bg-white" : "bg-slate-900" // Or theme color
                                    )}
                                    style={{ width: `${item.progress}%` }}
                                />
                            </div>
                        </div>
                      );
                  })
              ) : (
                  <div className="text-center py-10 text-zinc-500">
                      No downloads in progress
                  </div>
              )
          ) : (
              <div className="space-y-4">
                {completedItems.length > 0 && (
                    <div className="flex justify-end">
                        <button 
                            onClick={clearCompletedDownloads}
                            className="text-xs text-red-500 flex items-center gap-1 hover:text-red-600"
                        >
                            <Trash2 size={12} /> Clear All
                        </button>
                    </div>
                )}
                {completedItems.length > 0 ? (
                    completedItems.map(item => (
                        <AppListItem key={item.appId} app={getApp(item.appId)} isDownloaded />
                    ))
                ) : (
                    <div className="text-center py-10 text-zinc-500">
                        No completed downloads
                    </div>
                )}
              </div>
          )}
      </div>

    </div>
  );
};
