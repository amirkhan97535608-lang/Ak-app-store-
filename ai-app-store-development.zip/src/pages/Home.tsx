
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { APPS, CATEGORIES } from '@/data/mockData';
import { AppCard } from '@/components/shared/AppCard';
import { CategoryChip } from '@/components/shared/CategoryChip';
import { AppListItem } from '@/components/shared/AppListItem';
import { useStore } from '@/store/useStore';
import { cn } from '@/utils/cn';

export const Home = () => {
  const navigate = useNavigate();
  const { darkMode, searchQuery } = useStore();

  const filteredApps = APPS.filter(app => 
    app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    app.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (searchQuery) {
    return (
      <div className={cn("min-h-screen pt-[70px] pb-[80px] px-4 space-y-4", darkMode ? "bg-zinc-900" : "bg-slate-50")}>
        <h2 className={cn("font-semibold", darkMode ? "text-white" : "text-slate-900")}>Search Results</h2>
        <div className="flex flex-col gap-3">
            {filteredApps.length > 0 ? (
                filteredApps.map(app => (
                    <AppListItem key={app.id} app={app} />
                ))
            ) : (
                <p className="text-center text-zinc-500 mt-10">No apps found</p>
            )}
        </div>
      </div>
    );
  }

  return (
    <div className={cn("min-h-screen pt-[70px] pb-[80px] space-y-6", darkMode ? "bg-zinc-900" : "bg-slate-50")}>
      
      {/* Featured Section */}
      <section className="px-4">
        <div className="flex items-center justify-between mb-3">
            <h2 className={cn("text-lg font-bold", darkMode ? "text-white" : "text-slate-900")}>Featured</h2>
        </div>
        <div className="flex overflow-x-auto gap-4 pb-4 -mx-4 px-4 scrollbar-hide">
            {APPS.slice(0, 3).map(app => (
                <AppCard key={app.id} app={app} featured />
            ))}
        </div>
      </section>

      {/* Categories Section */}
      <section className="pl-4">
        <div className="flex items-center justify-between mb-3 pr-4">
            <h2 className={cn("text-lg font-bold", darkMode ? "text-white" : "text-slate-900")}>Categories</h2>
            <button 
                onClick={() => navigate('/categories')}
                className={cn("text-sm font-medium", darkMode ? "text-sky-400" : "text-sky-600")}
            >
                See All
            </button>
        </div>
        <div className="flex overflow-x-auto gap-3 pb-2 pr-4 scrollbar-hide">
            {CATEGORIES.map(cat => (
                <CategoryChip 
                    key={cat.id} 
                    category={cat} 
                    onClick={() => navigate(`/categories?cat=${cat.name}`)}
                />
            ))}
        </div>
      </section>

      {/* Recently Added Section */}
      <section className="px-4">
        <div className="flex items-center justify-between mb-3">
            <h2 className={cn("text-lg font-bold", darkMode ? "text-white" : "text-slate-900")}>Recently Added</h2>
        </div>
        <div className="flex flex-col gap-3">
            {APPS.map(app => (
                <AppListItem key={app.id} app={app} />
            ))}
        </div>
      </section>

    </div>
  );
};
