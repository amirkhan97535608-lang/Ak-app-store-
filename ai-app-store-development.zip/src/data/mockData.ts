
export interface AppData {
  id: string;
  name: string;
  category: string;
  description: string;
  icon: string;
  screenshots: string[];
  version: string;
  size: string;
  downloads: string;
  rating: number;
}

export interface CategoryData {
  id: string;
  name: string;
  iconName: string;
  count: number;
}

export const CATEGORIES: CategoryData[] = [
  { id: '1', name: 'Social', iconName: 'MessageCircle', count: 120 },
  { id: '2', name: 'Games', iconName: 'Gamepad2', count: 450 },
  { id: '3', name: 'Productivity', iconName: 'Briefcase', count: 85 },
  { id: '4', name: 'Tools', iconName: 'Wrench', count: 60 },
  { id: '5', name: 'Education', iconName: 'GraduationCap', count: 40 },
  { id: '6', name: 'Entertainment', iconName: 'Film', count: 200 },
];

export const APPS: AppData[] = [
  {
    id: '1',
    name: 'ChatMaster',
    category: 'Social',
    description: 'Connect with friends and family instantly. Features secure messaging, video calls, and group chats. Experience the future of communication with our AI-powered translation tools.',
    icon: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=512&h=512&fit=crop',
    screenshots: [
      'https://images.unsplash.com/photo-1611162616475-46b635cb6868?w=800&h=450&fit=crop',
      'https://images.unsplash.com/photo-1596558450268-9c27524ba856?w=800&h=450&fit=crop'
    ],
    version: '2.4.1',
    size: '45 MB',
    downloads: '1M+',
    rating: 4.5
  },
  {
    id: '2',
    name: 'Space Runner',
    category: 'Games',
    description: 'Endless runner game set in space. Dodge asteroids, collect power-ups, and compete with players worldwide. Stunning graphics and addictive gameplay await!',
    icon: 'https://images.unsplash.com/photo-1556707752-481d500a2c58?w=512&h=512&fit=crop',
    screenshots: [
        'https://images.unsplash.com/photo-1614720183822-e8405843d638?w=800&h=450&fit=crop',
        'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&h=450&fit=crop'
    ],
    version: '1.0.5',
    size: '120 MB',
    downloads: '500K+',
    rating: 4.8
  },
  {
    id: '3',
    name: 'TaskFlow',
    category: 'Productivity',
    description: 'Manage your tasks efficiently with AI suggestions. Organize your life, set reminders, and collaborate with your team in real-time.',
    icon: 'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?w=512&h=512&fit=crop',
    screenshots: [
        'https://images.unsplash.com/photo-1517048676732-d65bc937f952?w=800&h=450&fit=crop'
    ],
    version: '3.2.0',
    size: '25 MB',
    downloads: '2M+',
    rating: 4.7
  },
  {
    id: '4',
    name: 'PhotoPro',
    category: 'Tools',
    description: 'Professional photo editing on the go. Filters, effects, and advanced editing tools at your fingertips.',
    icon: 'https://images.unsplash.com/photo-1520390138845-fd2d229dd552?w=512&h=512&fit=crop',
    screenshots: [],
    version: '5.1.0',
    size: '80 MB',
    downloads: '10M+',
    rating: 4.6
  },
  {
    id: '5',
    name: 'LearnCode',
    category: 'Education',
    description: 'Master programming languages with interactive lessons. Python, JavaScript, Java, and more.',
    icon: 'https://images.unsplash.com/photo-1587620962725-abab7fe55159?w=512&h=512&fit=crop',
    screenshots: [],
    version: '1.2.3',
    size: '60 MB',
    downloads: '100K+',
    rating: 4.9
  },
  {
    id: '6',
    name: 'StreamFlix',
    category: 'Entertainment',
    description: 'Watch your favorite movies and TV shows. Personalized recommendations and offline viewing.',
    icon: 'https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=512&h=512&fit=crop',
    screenshots: [],
    version: '8.0.1',
    size: '55 MB',
    downloads: '5M+',
    rating: 4.3
  }
];

export interface Notification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  type: 'system' | 'update' | 'promo';
}

export const NOTIFICATIONS: Notification[] = [
  {
    id: '1',
    title: 'Welcome to AK APP STORE!',
    message: 'Explore thousands of apps curated just for you.',
    timestamp: '2 hours ago',
    read: false,
    type: 'system'
  },
  {
    id: '2',
    title: 'New Update Available',
    message: 'Space Runner has a new update with 5 new levels.',
    timestamp: '1 day ago',
    read: true,
    type: 'update'
  }
];
