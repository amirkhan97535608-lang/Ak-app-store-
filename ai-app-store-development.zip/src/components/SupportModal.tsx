
import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Bot, User } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { cn } from '@/utils/cn';
import { THEME_CONFIG } from '@/utils/theme';

interface Message {
  id: string;
  text: string;
  isBot: boolean;
}

export const SupportModal = ({ onClose }: { onClose: () => void }) => {
  const { darkMode, themeColor } = useStore();
  const theme = THEME_CONFIG[themeColor];
  
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', text: 'Hello! I am your AI Assistant. How can I help you today?', isBot: true }
  ]);
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;
    
    const userMsg: Message = { id: Date.now().toString(), text: input, isBot: false };
    setMessages(prev => [...prev, userMsg]);
    setInput('');

    // Simulate AI response
    setTimeout(() => {
        const botMsg: Message = { 
            id: (Date.now() + 1).toString(), 
            text: `I understand you're asking about "${userMsg.text}". As an AI demo, I can tell you that AK APP STORE is designed to be intuitive and fast!`, 
            isBot: true 
        };
        setMessages(prev => [...prev, botMsg]);
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className={cn(
          "w-full max-w-md h-[600px] flex flex-col rounded-2xl shadow-2xl overflow-hidden",
          darkMode ? "bg-zinc-900" : "bg-white"
      )}>
        {/* Header */}
        <div className={cn(
            "p-4 flex items-center justify-between border-b",
            darkMode ? "border-zinc-800" : "border-slate-100"
        )}>
            <div className="flex items-center gap-3">
                <div className={cn("w-10 h-10 rounded-full flex items-center justify-center", theme.gradient)}>
                    <Bot className="text-white" size={24} />
                </div>
                <div>
                    <h3 className={cn("font-bold", darkMode ? "text-white" : "text-slate-900")}>AI Support</h3>
                    <p className="text-xs text-green-500 flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" /> Online
                    </p>
                </div>
            </div>
            <button onClick={onClose} className={cn("p-2 rounded-full", darkMode ? "hover:bg-zinc-800" : "hover:bg-slate-100")}>
                <X size={24} className={cn(darkMode ? "text-zinc-400" : "text-slate-500")} />
            </button>
        </div>

        {/* Chat Area */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map(msg => (
                <div key={msg.id} className={cn("flex gap-3", msg.isBot ? "justify-start" : "justify-end")}>
                    {msg.isBot && (
                        <div className={cn("w-8 h-8 rounded-full flex items-center justify-center shrink-0 bg-opacity-10", theme.primaryText.replace('text-', 'bg-').replace('600', '500').replace('900', '200'))}>
                            <Bot size={16} className={theme.primaryText} />
                        </div>
                    )}
                    <div className={cn(
                        "p-3 rounded-2xl max-w-[80%] text-sm",
                        msg.isBot 
                            ? (darkMode ? "bg-zinc-800 text-zinc-200" : "bg-slate-100 text-slate-800") 
                            : (theme.primaryBg + " text-white")
                    )}>
                        {msg.text}
                    </div>
                </div>
            ))}
        </div>

        {/* Input */}
        <div className={cn("p-4 border-t", darkMode ? "border-zinc-800" : "border-slate-100")}>
            <div className="flex items-center gap-2">
                <input 
                    type="text" 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Type your message..."
                    className={cn(
                        "flex-1 p-3 rounded-xl outline-none text-sm",
                        darkMode ? "bg-zinc-800 text-white placeholder:text-zinc-500" : "bg-slate-50 text-slate-900 placeholder:text-slate-400"
                    )}
                />
                <button 
                    onClick={handleSend}
                    className={cn("p-3 rounded-xl text-white transition-colors hover:brightness-110", theme.primaryBg)}
                >
                    <Send size={20} />
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};
