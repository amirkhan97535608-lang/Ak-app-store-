
import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Bell, Search, ChevronLeft, Menu } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { cn } from '@/utils/cn';

export const Header = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { darkMode, searchQuery, setSearchQuery, notifications } = useStore();
  
  const unreadCount = notifications.filter(n => !n.read).length;

  const isHome = location.pathname === '/';
  
  const getTitle = () => {
    if (location.pathname === '/categories') return 'Categories';
    if (location.pathname === '/downloads') return 'Downloads';
    if (location.pathname === '/settings') return 'Settings';
    if (location.pathname === '/notifications') return 'Notifications';
    if (location.pathname.startsWith('/app/')) return 'App Details';
    return 'AK APP STORE';
  };

  return (
    <header className={cn(
      "fixed top-0 left-0 right-0 h-[60px] px-4 flex items-center justify-between z-40 transition-colors duration-300",
      darkMode ? "bg-zinc-900/95 backdrop-blur border-b border-zinc-800" : "bg-white/95 backdrop-blur border-b border-slate-200"
    )}>
      {isHome ? (
        <div className="flex items-center gap-3 w-full">
            <div className="flex-1 relative">
                <Search className={cn("absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4", darkMode ? "text-zinc-500" : "text-slate-400")} />
                <input 
                    type="text" 
                    placeholder="Search apps..." 
                    className={cn(
                        "w-full h-10 pl-9 pr-4 rounded-full text-sm outline-none transition-all",
                        darkMode ? "bg-zinc-800 text-white placeholder:text-zinc-500 focus:bg-zinc-700" : "bg-slate-100 text-slate-900 placeholder:text-slate-500 focus:bg-slate-200"
                    )}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
            </div>
            <button onClick={() => navigate('/notifications')} className="relative p-2 rounded-full hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                <Bell className={cn("w-6 h-6", darkMode ? "text-zinc-300" : "text-slate-700")} />
                {unreadCount > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white dark:border-zinc-900"></span>
                )}
            </button>
        </div>
      ) : (
        <div className="flex items-center w-full gap-3">
            {location.pathname !== '/' && (
                <button onClick={() => navigate(-1)} className={cn("p-1 rounded-full", darkMode ? "hover:bg-white/10 text-zinc-300" : "hover:bg-black/5 text-slate-700")}>
                    <ChevronLeft className="w-6 h-6" />
                </button>
            )}
            <h1 className={cn("text-lg font-semibold", darkMode ? "text-white" : "text-slate-900")}>
                {getTitle()}
            </h1>
        </div>
      )}
    </header>
  );
};
