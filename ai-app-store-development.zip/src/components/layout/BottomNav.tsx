
import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Grid, Settings, Download } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { cn } from '@/utils/cn';
import { getThemeConfig } from '@/utils/theme';

export const BottomNav = () => {
  const { themeColor, darkMode } = useStore();

  const activeColorClass = getThemeConfig(themeColor).primaryText;

  const navItems = [
    { to: '/', icon: Home, label: 'Home' },
    { to: '/categories', icon: Grid, label: 'Category' },
    { to: '/downloads', icon: Download, label: 'Downloads' },
    { to: '/settings', icon: Settings, label: 'Settings' },
  ];

  return (
    <nav className={cn(
      "fixed bottom-0 left-0 right-0 border-t pb-safe-bottom pt-2 px-6 h-[70px] flex justify-between items-start z-40 transition-colors duration-300",
      darkMode ? "bg-zinc-900 border-zinc-800" : "bg-white border-slate-200"
    )}>
      {navItems.map(({ to, icon: Icon, label }) => (
        <NavLink
          key={to}
          to={to}
          className={({ isActive }) => cn(
            "flex flex-col items-center gap-1 transition-colors",
            isActive 
              ? activeColorClass 
              : (darkMode ? "text-zinc-500 hover:text-zinc-300" : "text-slate-400 hover:text-slate-600")
          )}
        >
          <Icon size={24} strokeWidth={2} />
          <span className="text-[10px] font-medium">{label}</span>
        </NavLink>
      ))}
    </nav>
  );
};
