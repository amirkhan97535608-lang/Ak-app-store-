
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Download, Star, Check } from 'lucide-react';
import { AppData } from '@/data/mockData';
import { useStore } from '@/store/useStore';
import { cn } from '@/utils/cn';
import { THEME_CONFIG } from '@/utils/theme';

interface AppListItemProps {
  app: AppData;
  isDownloaded?: boolean;
}

export const AppListItem = ({ app, isDownloaded = false }: AppListItemProps) => {
  const navigate = useNavigate();
  const { darkMode, themeColor } = useStore();

  const theme = THEME_CONFIG[themeColor];

  return (
    <div 
      onClick={() => navigate(`/app/${app.id}`)}
      className={cn(
        "flex items-center gap-4 p-3 rounded-2xl transition-all active:scale-[0.98]",
        darkMode ? "bg-zinc-800/50" : "bg-white border border-slate-100 shadow-sm"
      )}
    >
      <img src={app.icon} alt={app.name} className="w-16 h-16 rounded-xl object-cover" />
      
      <div className="flex-1 min-w-0">
        <h3 className={cn("font-semibold truncate", darkMode ? "text-white" : "text-slate-900")}>
            {app.name}
        </h3>
        <p className={cn("text-xs truncate mb-1", darkMode ? "text-zinc-400" : "text-slate-500")}>
            {app.category} • {app.size}
        </p>
        <div className="flex items-center gap-1">
            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
            <span className={cn("text-xs font-medium", darkMode ? "text-zinc-300" : "text-slate-700")}>
                {app.rating}
            </span>
        </div>
      </div>

      <button className={cn(
        "p-2 rounded-full transition-colors",
        isDownloaded 
          ? (darkMode ? "bg-zinc-700 text-zinc-300" : "bg-slate-100 text-slate-600")
          : (theme.primaryBg + " text-white")
      )}>
        {isDownloaded ? <Check size={20} className="text-emerald-500" /> : <Download size={20} />}
      </button>
    </div>
  );
};
