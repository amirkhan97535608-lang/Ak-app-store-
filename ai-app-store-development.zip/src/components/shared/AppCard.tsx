
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Star } from 'lucide-react';
import { AppData } from '@/data/mockData';
import { useStore } from '@/store/useStore';
import { cn } from '@/utils/cn';

interface AppCardProps {
  app: AppData;
  featured?: boolean;
}

export const AppCard = ({ app, featured = false }: AppCardProps) => {
  const navigate = useNavigate();
  const { darkMode } = useStore();

  return (
    <div 
      onClick={() => navigate(`/app/${app.id}`)}
      className={cn(
        "flex flex-col gap-2 p-3 rounded-2xl transition-all cursor-pointer active:scale-95",
        darkMode ? "bg-zinc-800/50 hover:bg-zinc-800" : "bg-white border border-slate-100 shadow-sm hover:shadow-md",
        featured ? "min-w-[280px]" : "min-w-[140px]"
      )}
    >
      <img 
        src={app.icon} 
        alt={app.name} 
        className={cn(
          "rounded-xl object-cover",
          featured ? "w-full h-32" : "w-full h-32"
        )}
      />
      <div className="flex flex-col gap-1">
        <h3 className={cn("font-semibold truncate", darkMode ? "text-white" : "text-slate-900")}>
            {app.name}
        </h3>
        <p className={cn("text-xs truncate", darkMode ? "text-zinc-400" : "text-slate-500")}>
            {app.category}
        </p>
        <div className="flex items-center gap-1 mt-1">
            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
            <span className={cn("text-xs font-medium", darkMode ? "text-zinc-300" : "text-slate-700")}>
                {app.rating}
            </span>
        </div>
      </div>
    </div>
  );
};
