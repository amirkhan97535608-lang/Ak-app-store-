
import React from 'react';
import * as Icons from 'lucide-react';
import { CategoryData } from '@/data/mockData';
import { useStore } from '@/store/useStore';
import { cn } from '@/utils/cn';
import { THEME_CONFIG } from '@/utils/theme';

interface CategoryChipProps {
  category: CategoryData;
  active?: boolean;
  onClick?: () => void;
}

export const CategoryChip = ({ category, active, onClick }: CategoryChipProps) => {
  const { darkMode, themeColor } = useStore();
  const Icon = (Icons as any)[category.iconName] || Icons.HelpCircle;

  // Fix logic for dark mode + active
  const getActiveClass = () => {
      if (!active) return darkMode ? "bg-zinc-800 text-zinc-300 hover:bg-zinc-700" : "bg-slate-100 text-slate-600 hover:bg-slate-200";
      
      // If active
      if (themeColor === 'zinc' && darkMode) {
        return 'bg-white text-black';
      }
      if (themeColor === 'slate' && darkMode) {
        return 'bg-white text-black';
      }

      const theme = THEME_CONFIG[themeColor];
      return `${theme.primaryBg} text-white`;
  };

  return (
    <button
      onClick={onClick}
      className={cn(
        "flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap",
        getActiveClass()
      )}
    >
      <Icon size={16} />
      <span>{category.name}</span>
    </button>
  );
};
