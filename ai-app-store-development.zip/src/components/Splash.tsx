
import React, { useEffect } from 'react';
import { useStore } from '@/store/useStore';
import { cn } from '@/utils/cn';
import { getThemeConfig } from '@/utils/theme';

export const Splash = () => {
  const { setShowSplash, themeColor } = useStore();

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2500);

    return () => clearTimeout(timer);
  }, [setShowSplash]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-zinc-900 text-white">
      <div className={cn(
        "relative flex items-center justify-center w-24 h-24 mb-6 rounded-3xl shadow-2xl animate-pulse",
        getThemeConfig(themeColor).gradient,
        getThemeConfig(themeColor).ring.replace('ring-', 'shadow-').replace('500', '500/20')
      )}>
        <span className="text-4xl font-bold">AK</span>
      </div>
      <h1 className="text-3xl font-bold tracking-tight mb-2">AK APP STORE</h1>
      <p className="text-zinc-400 text-sm">Discover. Download. Enjoy.</p>
      
      <div className="absolute bottom-8 text-xs text-zinc-600">
        Version 1.0.0
      </div>
    </div>
  );
};
