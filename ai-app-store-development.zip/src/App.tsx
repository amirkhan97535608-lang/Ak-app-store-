
import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { MessageCircle } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { cn } from '@/utils/cn';
import { getThemeConfig } from '@/utils/theme';

// Components
import { Splash } from '@/components/Splash';
import { Header } from '@/components/layout/Header';
import { BottomNav } from '@/components/layout/BottomNav';
import { SupportModal } from '@/components/SupportModal';

// Pages
import { Home } from '@/pages/Home';
import { Categories } from '@/pages/Categories';
import { AppDetails } from '@/pages/AppDetails';
import { Downloads } from '@/pages/Downloads';
import { Settings } from '@/pages/Settings';
import { Notifications } from '@/pages/Notifications';

const Layout = ({ children }: { children: React.ReactNode }) => {
  const location = useLocation();
  const hideBottomNav = location.pathname.startsWith('/app/') || location.pathname === '/notifications';

  return (
    <>
      <Header />
      <main className="min-h-screen">
        {children}
      </main>
      {!hideBottomNav && <BottomNav />}
    </>
  );
};

export function App() {
  const { showSplash, darkMode } = useStore();
  const [isSupportOpen, setIsSupportOpen] = useState(false);

  if (showSplash) {
    return <Splash />;
  }

  return (
    <BrowserRouter>
      <div className={cn("min-h-screen antialiased", darkMode ? "bg-zinc-900" : "bg-slate-50")}>
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/categories" element={<Categories />} />
            <Route path="/app/:id" element={<AppDetails />} />
            <Route path="/downloads" element={<Downloads />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/notifications" element={<Notifications />} />
          </Routes>
        </Layout>

        {/* Support FAB */}
        <button
          onClick={() => setIsSupportOpen(true)}
          className={cn(
            "fixed bottom-24 right-4 p-4 rounded-full text-white shadow-lg hover:scale-110 transition-transform z-30",
            getThemeConfig(useStore().themeColor).gradient,
            getThemeConfig(useStore().themeColor).ring.replace('ring-', 'shadow-').replace('500', '500/30') // Approximate shadow
          )}
        >
          <MessageCircle size={24} />
        </button>

        {isSupportOpen && <SupportModal onClose={() => setIsSupportOpen(false)} />}
      </div>
    </BrowserRouter>
  );
}
